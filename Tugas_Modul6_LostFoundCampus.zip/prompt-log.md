# Prompt Log Modul 6

## Sumber desain

- Link Figma: https://www.figma.com/design/CLcDJykpxTYtmAoC3KansM/Untitled?node-id=0-1
- Materi tugas: Modul 6 Konversi Desain Figma ke HTML5.
- Tema yang diterjemahkan: layanan lost and found kampus dengan alur landing, login, dashboard, daftar laporan, formulir laporan, detail barang, klaim, dan percakapan petugas.

## Prompt utama

```text
Buatkan struktur HTML5 semantik dari desain Figma layanan lost and found kampus. Ikuti ketentuan Modul 6: tanpa CSS eksternal, tanpa tag style, tanpa framework, tanpa inline style, memakai minimal 8 halaman HTML, gambar dengan alt, form dengan label for/id, tabel data, daftar, navigasi, header, main, section, article, dan footer.
```

## Evaluasi kode awal

- Kode harus bersih dari div-soup, sehingga struktur memakai tag semantik.
- Semua halaman memakai satu h1 utama dan heading turun secara runtut.
- Semua form memakai fieldset, legend, label, input, textarea, select, dan button type submit.
- Gambar dipanggil dari jalur relatif `./assets/images/` dan memiliki teks alternatif.

## Refaktorisasi akhir

- Navigasi dibuat konsisten di seluruh halaman.
- Halaman beranda menambahkan ordered list, unordered list, tabel ringkasan, dan gambar hero.
- Halaman daftar laporan memakai tabel dengan caption, thead, tbody, th scope, dan tautan detail.
- Halaman percakapan memakai beberapa article untuk membedakan pesan petugas dan mahasiswa.
- Aset SVG diletakkan di `assets/images/` agar folder gambar mandiri tersedia.

## Catatan batasan

- Akses Figma publik dapat dilihat secara visual, tetapi inspect detail dan ekspor aset asli dibatasi oleh permintaan sign up atau login Figma.
- Aset SVG lokal dibuat sebagai representasi semantik dari desain layanan lost and found agar struktur tugas tetap lengkap.
- Setelah versi awal, stylesheet eksternal `style.css` ditambahkan atas permintaan lanjutan untuk memberi tampilan visual pada seluruh halaman.
- Penambahan CSS menyimpang dari ketentuan PDF yang melarang CSS. Gunakan versi tanpa stylesheet bila penilaian mewajibkan aturan itu.
- Tampilan CSS memakai palet biru dan hijau dari SVG lokal. Kecocokan persis dengan Figma belum dapat diverifikasi karena detail kanvas dan aset aslinya tidak terbaca.
